set(0, 'DefaultLineLineWidth', 2)
set(0, 'DefaultaxesLineWidth', 2)
set(0, "DefaultLineMarkerSize", 10)

set(0, 'DefaultaxesFontSize', 24)
set(0, 'DefaultTextFontSize', 24)
set(0, 'DefaultaxesFontName', 'arial')